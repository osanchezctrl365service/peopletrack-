# PeopleTrack — Patrones de código

Patrones probados y aprobados para el proyecto. **Usar estos templates** al desarrollar features nuevas.

---

## Frontend

### 1. showSection consolidada (UNA SOLA, sin overrides)

```javascript
function showSection(sectionId) {
  // Ocultar todas las secciones
  document.querySelectorAll('.section').forEach(s => {
    s.style.display = 'none';
  });

  const section = document.getElementById(sectionId);
  if (!section) {
    console.error(`Section ${sectionId} not found`);
    return;
  }
  section.style.display = 'block';

  // Lazy-load según sección
  switch (sectionId) {
    case 'sec-help':       loadHelpArticles(); break;
    case 'sec-alertas':    loadAlertas(); break;
    case 'sec-onboarding': cargarOnboardings(); break;
    case 'sec-recruiting': cargarCandidatos(); break;
    case 'sec-pip':        cargarPIPs(); break;
    case 'sec-meetings':   cargarReuniones(); break;
    // agregar nuevos casos acá
  }

  // Marcar item activo en sidebar
  document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
  const activeItem = document.querySelector(`[data-section="${sectionId}"]`);
  if (activeItem) activeItem.classList.add('active');
}
```

> ⛔ **No** redefinir esta función al final del script. Si necesitás cambiar comportamiento, modificá el switch arriba.

### 2. Loader con fetch directo (para módulos críticos)

```javascript
async function loadHelpArticles() {
  const container = document.getElementById('help-articles-container');
  container.innerHTML = '<p class="loading">Cargando...</p>';

  try {
    const res = await fetch(`${API_BASE}/help-articles`, {
      credentials: 'include',
      headers: { 'Accept': 'application/json' }
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${await res.text()}`);
    }

    const articles = await res.json();
    renderHelpArticles(articles);
  } catch (err) {
    console.error('Error cargando artículos:', err);
    container.innerHTML = `<p class="error">Error: ${err.message}</p>`;
  }
}
```

### 3. Botón delete con overlay + closure

```javascript
// CORRECTO — usa closure
function bindDeleteButton(btnId, itemId, itemName) {
  const btn = document.getElementById(btnId);
  if (!btn) return;

  btn.addEventListener('click', () => {
    showConfirmOverlay({
      title: '¿Eliminar?',
      message: `Vas a eliminar: ${itemName}`,
      onConfirm: async () => {
        await softDeleteItem(itemId);
        await reloadList();
      }
    });
  });
}

// EVITAR — se rompe con comillas o caracteres especiales en itemName
// `<button onclick="confirmDelete('${itemId}', '${itemName}')">`
```

### 4. Modal de dos columnas (para 1366×768)

```html
<div class="modal-content modal-two-col">
  <div class="modal-col-left">
    <!-- Form fields columna izquierda -->
  </div>
  <div class="modal-col-right">
    <!-- Form fields columna derecha -->
  </div>
</div>
```

```css
.modal-two-col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  max-height: 80vh;
  overflow-y: auto;
}
```

### 5. POST a la API

```javascript
async function crearItem(data) {
  try {
    const res = await fetch(`${API_BASE}/items`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`HTTP ${res.status}: ${errText}`);
    }

    return await res.json();
  } catch (err) {
    console.error('Error creando item:', err);
    showError(err.message);
    throw err;
  }
}
```

---

## Backend (Azure Functions)

### 6. Endpoint GET con query

```javascript
const sql = require('mssql');

module.exports = async function (context, req) {
  try {
    const pool = await sql.connect(SQL_CONFIG);

    const result = await pool.request()
      .input('userId', sql.Int, parseInt(req.params.userId))
      .query(`
        SELECT *
        FROM OneOnOneMeetings
        WHERE UserID = @userId AND IsDeleted = 0
        ORDER BY MeetingDate DESC
      `);

    context.res = {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: result.recordset
    };
  } catch (err) {
    context.log.error('Error in GET meetings:', err);
    context.res = {
      status: 500,
      body: { error: err.message }
    };
  }
};
```

### 7. Endpoint POST con validación

```javascript
module.exports = async function (context, req) {
  try {
    const { userId, title, notes, meetingDate } = req.body || {};

    if (!userId || !title || !meetingDate) {
      context.res = {
        status: 400,
        body: { error: 'userId, title y meetingDate son requeridos' }
      };
      return;
    }

    const pool = await sql.connect(SQL_CONFIG);

    const result = await pool.request()
      .input('userId', sql.Int, parseInt(userId))
      .input('title', sql.NVarChar(255), title)
      .input('notes', sql.NVarChar(sql.MAX), notes || '')
      .input('meetingDate', sql.DateTime, new Date(meetingDate))
      .query(`
        INSERT INTO OneOnOneMeetings (UserID, Title, Notes, MeetingDate, IsDeleted)
        OUTPUT INSERTED.*
        VALUES (@userId, @title, @notes, @meetingDate, 0)
      `);

    context.res = {
      status: 201,
      body: result.recordset[0]
    };
  } catch (err) {
    context.log.error('Error creating meeting:', err);
    context.res = {
      status: 500,
      body: { error: err.message }
    };
  }
};
```

### 8. Soft-delete endpoint

```javascript
module.exports = async function (context, req) {
  try {
    const id = parseInt(req.params.id);
    if (!id) {
      context.res = { status: 400, body: { error: 'ID requerido' } };
      return;
    }

    const pool = await sql.connect(SQL_CONFIG);

    const result = await pool.request()
      .input('id', sql.Int, id)
      .query(`
        UPDATE OneOnOneMeetings
        SET IsDeleted = 1, UpdatedAt = GETDATE()
        OUTPUT INSERTED.*
        WHERE MeetingID = @id AND IsDeleted = 0
      `);

    if (result.recordset.length === 0) {
      context.res = { status: 404, body: { error: 'No encontrado' } };
      return;
    }

    context.res = { status: 200, body: { success: true } };
  } catch (err) {
    context.log.error('Error in soft-delete:', err);
    context.res = { status: 500, body: { error: err.message } };
  }
};
```

### 9. Upload de archivo (Recruiting / Onboarding)

```javascript
module.exports = async function (context, req) {
  try {
    const { candidateId, fileName, fileData, mimeType } = req.body || {};

    if (!candidateId || !fileName || !fileData) {
      context.res = { status: 400, body: { error: 'Datos incompletos' } };
      return;
    }

    const pool = await sql.connect(SQL_CONFIG);

    const result = await pool.request()
      .input('candidateId', sql.Int, parseInt(candidateId))
      .input('fileName', sql.NVarChar(255), fileName)
      .input('fileData', sql.VarBinary(sql.MAX), Buffer.from(fileData, 'base64'))
      .input('mimeType', sql.NVarChar(100), mimeType || 'application/octet-stream')
      .query(`
        INSERT INTO CandidateFiles (CandidateID, FileName, FileData, MimeType, UploadedAt)
        OUTPUT INSERTED.FileID, INSERTED.FileName, INSERTED.UploadedAt
        VALUES (@candidateId, @fileName, @fileData, @mimeType, GETDATE())
      `);

    context.res = { status: 201, body: result.recordset[0] };
  } catch (err) {
    context.log.error('Error uploading file:', err);
    context.res = { status: 500, body: { error: err.message } };
  }
};
```

---

## SQL

### 10. Agregar columna idempotente

```sql
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'OneOnOneMeetings' AND COLUMN_NAME = 'Title'
)
BEGIN
  ALTER TABLE [dbo].[OneOnOneMeetings] ADD Title NVARCHAR(255) NULL;
END;
```

### 11. Agregar permiso DELETE

```sql
GRANT DELETE ON [dbo].[NombreTabla] TO peopletrack_app;
```

### 12. Crear tabla con convención del proyecto

```sql
CREATE TABLE [dbo].[NuevaTabla] (
  NuevaTablaID    INT IDENTITY(1,1) PRIMARY KEY,
  UserID          INT NOT NULL,
  Nombre          NVARCHAR(255) NOT NULL,
  Descripcion     NVARCHAR(MAX) NULL,
  CreatedAt       DATETIME NOT NULL DEFAULT GETDATE(),
  UpdatedAt       DATETIME NULL,
  IsDeleted       BIT NOT NULL DEFAULT 0,
  CONSTRAINT FK_NuevaTabla_Users FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[NuevaTabla] TO peopletrack_app;
```
