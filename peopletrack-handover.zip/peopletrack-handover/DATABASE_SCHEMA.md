# PeopleTrack — Esquema de Base de Datos

> **DB:** `ctrl365serverlogic.database.windows.net / PeopleTrackDB`
> **Usuario aplicativo:** `peopletrack_app`
> **24 tablas** (estado abril 2026)

## Tablas

### Core / Organización

| Tabla | Propósito | Notas |
|---|---|---|
| `Users` | Empleados (~349) | Tabla maestra |
| `Leaders` | Asignación de líderes | FK a Users |
| `Areas` | Departamentos | |
| `Periods` | Ciclos de evaluación | |

### Performance

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `Objectives` | OKRs | |
| `CareerPlans` | Plan de carrera dinámico | |
| `CareerMilestones` | Hitos del plan | `FileData`, `BadgeURL`, `CertName` |
| `CertificationCatalog` | Catálogo (27 certs) | |
| `Competencies` | Competencias evaluables | |

### Engagement

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `OneOnOneMeetings` | Reuniones 1:1 | `IsDeleted`, `UpdatedAt`, `Title` |
| `Feedback360` | Feedback multifuente | |

### Onboarding

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `OnboardingPlans` | Planes de onboarding | `IsDeleted`, `CreatedAt` |
| `OnboardingMilestones` | Hitos | |
| `OnboardingCourses` | Cursos asociados | |

### Recruiting

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `Candidates` | Pipeline Kanban | |
| `CandidateInterviews` | Entrevistas | `InterviewerName`, `Result`, `Feedback` |
| `CandidateFiles` | Archivos adjuntos | |

### Performance management

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `PIPs` | Performance Improvement Plans | `IsDeleted` |

### Sistema

| Tabla | Propósito | Columnas clave |
|---|---|---|
| `HelpArticles` | Artículos de ayuda | `IsActive` |
| `Alerts` | Notificaciones | |
| `Changes` | Log de auditoría | |
| `Reports` | Reportes guardados | |

## Permisos críticos

`peopletrack_app` tiene **GRANT DELETE** sobre 9 tablas. Si agregás una tabla nueva con borrado, ejecutá:

```sql
GRANT DELETE ON [dbo].[NombreTabla] TO peopletrack_app;
```

## Convenciones

### Soft-delete

Tablas con soft-delete: `PIPs`, `OneOnOneMeetings`, `OnboardingPlans`

```sql
-- Marcar como borrado
UPDATE [Tabla] SET IsDeleted = 1, UpdatedAt = GETDATE() WHERE [PK] = @id;

-- Listar activos
SELECT * FROM [Tabla] WHERE IsDeleted = 0;
```

### Timestamps

Convención de columnas:
- `CreatedAt` — fecha de creación
- `UpdatedAt` — última actualización (auto-update en triggers o desde app)

### Foreign keys

Las FKs siguen el patrón `[NombreTabla]ID` (singular).
Ej: `UserID`, `AreaID`, `PeriodID`.

## SQL útil para diagnóstico

### Listar todas las tablas

```sql
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
```

### Ver columnas de una tabla

```sql
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'OneOnOneMeetings'
ORDER BY ORDINAL_POSITION;
```

### Ver permisos de peopletrack_app

```sql
SELECT
  pr.name AS PrincipalName,
  pe.permission_name,
  pe.state_desc,
  o.name AS ObjectName
FROM sys.database_permissions pe
JOIN sys.database_principals pr ON pe.grantee_principal_id = pr.principal_id
LEFT JOIN sys.objects o ON pe.major_id = o.object_id
WHERE pr.name = 'peopletrack_app'
ORDER BY o.name, pe.permission_name;
```

### Agregar columna IsDeleted a una tabla

```sql
ALTER TABLE [dbo].[NombreTabla]
  ADD IsDeleted BIT NOT NULL DEFAULT 0;
```

> ⚠️ Si la columna ya existe, el error de duplicate column es inofensivo — solo registrarlo.
