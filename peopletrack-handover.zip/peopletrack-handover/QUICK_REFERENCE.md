# PeopleTrack — Quick Reference

## URLs

```
Frontend:  https://yellow-water-0d91cc40f.1.azurestaticapps.net
API:       https://peopletrack-api-gjbbhhcefjbgc6bd.eastus2-01.azurewebsites.net/api
DB:        ctrl365serverlogic.database.windows.net / PeopleTrackDB
Repo:      github.com/osanchezctrl365service/peopletrack-
```

## Comandos esenciales

### Antes de cualquier cambio

```bash
cd C:\Agentes\peopletrack
git pull
git status

# Backup obligatorio
copy frontend\index.html frontend\index.html.bak.%date:~-4%%date:~3,2%%date:~0,2%
copy api\index.js api\index.js.bak.%date:~-4%%date:~3,2%%date:~0,2%
```

### Validar JS antes de deploy

```bash
node -c frontend/index.html  # NO funciona — es HTML
# Para JS embebido: extraer y validar manualmente con node -c <archivo.js>
```

### Deploy frontend

```bash
git add .
git commit -m "feat: descripción del cambio"
git push origin main
# GitHub Actions hace el resto
```

### Deploy API

VS Code → Azure Functions extension → click derecho en Function App → **"Deploy to Function App"**

## Branding rápido

| Elemento | Valor |
|---|---|
| Color primario | `#FF5400` (naranja CTRL365) |
| Background | `#0d0d0d` |
| Font headings | Sora |
| Font body | Inter |
| Theme | Dark |
| Resolución target | 1366×768 |

## Checklist pre-deploy

- [ ] Backup creado con timestamp
- [ ] JS validado con Node.js
- [ ] Sin overrides nuevos de `showSection`
- [ ] Loaders críticos usan `fetch` directo
- [ ] Soft-delete respetado (`WHERE IsDeleted = 0`)
- [ ] Botones delete usan overlay + closure
- [ ] Probado en 1366×768

## Reglas inviolables

1. ⛔ **Nunca** redefinir `showSection` al final del script
2. ⛔ **Nunca** acumular cambios sobre una base rota
3. ⛔ **Nunca** entregar diffs — siempre archivos completos
4. ✅ **Siempre** backup antes de modificar
5. ✅ **Siempre** validar JS antes de pushear
