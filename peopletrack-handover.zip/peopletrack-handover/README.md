# PeopleTrack — Paquete de Traspaso

Este ZIP contiene toda la documentación necesaria para retomar el desarrollo de PeopleTrack en una cuenta nueva de Claude.

## ⚠️ Aclaración importante

Este paquete contiene **documentación de traspaso**, no el código fuente de la aplicación.

El **código fuente vive en**:
- **GitHub:** `github.com/osanchezctrl365service/peopletrack-`
- **Local:** `C:\Agentes\peopletrack\frontend\index.html` y `C:\Agentes\peopletrack\api\index.js`

No se incluye el código en este ZIP por dos razones:
1. La fuente de verdad es el repo, no este paquete
2. Adjuntar `index.html` y `index.js` actuales requeriría que estén en esta sesión (no lo están)

## Contenido del paquete

| Archivo | Para qué sirve |
|---|---|
| **`HANDOVER.md`** | Documento principal de traspaso. **Empezar por acá.** |
| **`QUICK_REFERENCE.md`** | Tarjeta de referencia rápida: URLs, comandos, checklist pre-deploy |
| **`DATABASE_SCHEMA.md`** | Esquema completo de las 24 tablas + queries útiles |
| **`CODE_PATTERNS.md`** | Templates de código aprobados para frontend, backend y SQL |
| **`README.md`** | Este archivo |

## Cómo usar este paquete en una cuenta nueva de Claude

### Paso 1: Iniciar nueva conversación

Abrí Claude.ai en la cuenta nueva y arrancá un proyecto nuevo (recomendado para mantener el contexto).

### Paso 2: Subir los archivos

Subí los 4 .md como adjuntos al primer mensaje.

### Paso 3: Adjuntar también el código actual

Para que Claude pueda trabajar sobre la versión real, subí también:
- `frontend/index.html` (la versión más reciente del repo)
- `api/index.js` (la versión más reciente del repo)

### Paso 4: Mensaje inicial sugerido

```
Estoy retomando el desarrollo de PeopleTrack en una cuenta nueva.
Adjunto el documento de traspaso (HANDOVER.md) y el código actual.

Reglas de trabajo:
1. Siempre dame el archivo completo, nunca diffs ni edición manual
2. Antes de cualquier cambio, recordame crear un backup con timestamp
3. Validá el JS con Node.js antes de entregar
4. No agregues overrides a `showSection` — modificá la función original
5. Para loaders críticos, usá fetch directo, no apiGet

Confirmame que leíste el contexto y estoy listo para empezar con [tu primer task].
```

### Paso 5: Validar el contexto

Antes de pedir cambios grandes, dale un task chico para validar que entendió:
> "Mostrame el patrón de soft-delete que usamos en el proyecto"

Si responde correctamente con el patrón documentado, el contexto está bien transferido.

## Roadmap inmediato (de mayor a menor prioridad)

1. **Sistema de permisos por rol** (admin/manager/leader/employee)
2. **Verificación end-to-end** de módulos pendientes en producción
3. **Manuales de usuario** módulo por módulo
4. Auditoría completa del log de Cambios
5. Notificaciones por email desde Alertas
6. Export a Excel/PDF desde Reportes

## Reglas inviolables del proyecto

1. ⛔ **Nunca** redefinir `showSection` al final del script
2. ⛔ **Nunca** acumular cambios sobre una base potencialmente rota
3. ⛔ **Nunca** entregar diffs — siempre archivos completos
4. ✅ **Siempre** backup con timestamp antes de modificar
5. ✅ **Siempre** validar JS con Node.js antes de pushear
6. ✅ **Siempre** filtrar `WHERE IsDeleted = 0` en SELECTs de tablas con soft-delete

---

> **Generado:** Mayo 2026
> **Autor:** Orlan Sanchez (osanchez@ctrl365.com)
